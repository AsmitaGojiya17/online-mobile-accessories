<?php
include "connection.php";
$id=$_REQUEST['id'];
$cid=$_REQUEST['cid'];
mysqli_query($con,"delete from subcategory where subcat_id='$id'");
?>
<script>
	window.location="viewsubcategory.php?id=<?php echo $cid;?>";
</script>