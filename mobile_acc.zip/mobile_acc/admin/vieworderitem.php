<?php
include "header.php";
?>
		<div class="charts" >		
			<div class="mid-content-top charts-grids" >
				<div class="middle-content" >
						
					<h1>Order Items Listing</h1>
					
					<!-- start content_slider -->
					<div class="bs-example widget-shadow" data-example-id="hoverable-table"> 
						<div class="panel-body widget-shadow">
						<table class="table table-hover"> 
							<thead> 
								<tr>  
									<th>Id</th> 
									<th>Product Name</th> 
									<th>Image</th> 
									<th>Quantity</th> 
									<th>Price</th> 
									<th>Total Price</th> 
								</tr> 
							</thead> 
							<?php
							include "connection.php";
							$oid=$_REQUEST['id'];
							$c=mysqli_query($con,"select * from order_items_details where order_id='$oid'");
							while($r=mysqli_fetch_array($c))
							{
							?>
							<tbody> 
								<tr> 
									<td><?php echo $r['orde_item_id'];?></td> 
									<?php
									$id=$r['book_id'];
									$q1="select * from product_details where product_id='$id'";
									$c1=mysqli_query($con,$q1);
									while($r1=mysqli_fetch_array($c1))
									{
									?>
										<td><?php echo $r1['product_name'];?></td> 
										<td><img src="upload/product/<?php echo $r1['product_image'];?>" height=80 width=80 /></td> 
									
									<?php									
									}
																	
									?>
									<td><?php echo $r['quantity'];?></td> 
									<td><?php echo $r['price'];?></td> 
									<td><?php echo $r['total_price'];?></td> 
									
									
								</tr> 
							 </tbody>
							<?php
							}
							?>
						</table>
						</div>
					</div>
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
				
			</div>
		</div>
	
<?php
include "footer.php";
?>