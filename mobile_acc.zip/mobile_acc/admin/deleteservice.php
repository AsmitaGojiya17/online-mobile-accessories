<?php
include "connection.php";
$id=$_REQUEST['id'];
mysqli_query($con,"delete from services_master where service_id='$id'");
?>
<script>
	window.location="viewservice.php";
</script>