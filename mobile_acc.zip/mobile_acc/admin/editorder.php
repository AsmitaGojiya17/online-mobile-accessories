<?php

$id=$_REQUEST['id'];
$status=$_REQUEST['status'];
include "connection.php";
$q="update order_master set status='$status' where order_id='$id'";
$c=mysqli_query($con,$q);
?>
<script>
	window.location="vieworder.php";
</script>