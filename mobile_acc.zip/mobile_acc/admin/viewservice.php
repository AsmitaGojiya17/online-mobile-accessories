<?php
include "header.php";
?>


		<div class="charts" >		
			<div class="mid-content-top charts-grids" >
				<div class="middle-content" >
						
					<h1>Service Listing</h1>
					
					<!-- start content_slider -->
					<div class="bs-example widget-shadow" data-example-id="hoverable-table"> 
						<div class="panel-body widget-shadow">
						<table class="table table-hover"> 
							<thead> 
								<tr>  
									<th>ID</th> 
									<th>Username</th> 
									<th width=150>Title</th> 
									<th>Message</th> 
									<th>Image</th> 
									<th width=250>Address</th> 
									<th width=100>Date</th> 
									<th>Action</th> 
								</tr> 
							</thead> 
							<?php
								include "connection.php";
							$c=mysqli_query($con,"select * from services_master");
							while($r=mysqli_fetch_array($c))
							{
							?>
							<tbody> 
								<tr> 
									
									<td><?php echo $r['service_id'];?></td> 
									<?php
									$id=$r['username'];
									$q1="select * from customer where customer_id='$id'";
									$c1=mysqli_query($con,$q1);
									while($r1=mysqli_fetch_array($c1))
									{
									?>
										<td><?php echo $r1['name'];?></td> 
									
									<?php									
									}
									?>
									<td><?php echo $r['title'];?></td>  
									<td><?php echo $r['message'];?></td> 
									<td><img src="upload/service/<?php echo $r['image'];?>" height=100 width=100/></td> 
									<td><?php echo $r['address'];?></td> 
									<td><?php echo $r['s_date'];?></td> 
									<td>
									<a href="addstatus.php?id=<?php echo $r['service_id'];?>">
										Status
									</a>
									&nbsp;
									<a onClick="return confirm('Are You Sure You want to remove this information??')" href="deleteservice.php?id=<?php echo $r['service_id'];?>">
										<i  style="color: red;  font-size:18px" class="fa fa-trash-o" aria-hidden="true"></i>
									</a>
									</td> 
								</tr> 
							 </tbody>
							<?php
							}
							?>
						</table>
						</div>
					</div>
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
				
			</div>
		</div>
	
<?php
include "footer.php";
?>