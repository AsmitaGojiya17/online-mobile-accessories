<?php
include "connection.php";
$id=$_REQUEST['id'];
$sid=$_REQUEST['sid'];
mysqli_query($con,"delete from status_master where status_id='$id'");
?>
<script>
	window.location="addstatus.php?id=<?php echo $sid;?>";
</script>