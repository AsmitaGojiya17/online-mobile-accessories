<?php
session_start();
unset($_SESSION['admin']);

?>

<script>
	window.location="login.php";
</script>	
