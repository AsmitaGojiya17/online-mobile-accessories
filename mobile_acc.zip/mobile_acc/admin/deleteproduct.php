<?php
include "connection.php";
$id=$_REQUEST['id'];
mysqli_query($con,"delete from product_details where product_id='$id'");
?>
<script>
	window.location="viewproduct.php";
</script>