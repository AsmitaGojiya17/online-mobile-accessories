<?php
include "header.php";
?>
		<div class="charts" >		
			<div class="mid-content-top charts-grids" >
				<div class="middle-content" >
						
					<h1>Order Listing</h1>
					
					<!-- start content_slider -->
					<div class="bs-example widget-shadow" data-example-id="hoverable-table"> 
						<div class="panel-body widget-shadow">
						<table class="table table-hover"> 
							<thead> 
								<tr>  
									<th>Id</th> 
									<th>Username</th> 
									<th>Amount</th> 
									<th>Quantity</th> 
									<th>Date</th> 
									<th>Address</th> 
									<th>Status</th> 
									<th>Action</th> 
								</tr> 
							</thead> 
							<?php
							include "connection.php";
							$c=mysqli_query($con,"select * from order_master");
							while($r=mysqli_fetch_array($c))
							{
							?>
							<tbody> 
								<tr> 
									<td><?php echo $r['order_id'];?></td> 
									<?php
									$id=$r['username'];
									$q1="select * from customer where customer_id='$id'";
									$c1=mysqli_query($con,$q1);
									while($r1=mysqli_fetch_array($c1))
									{
									?>
										<td><?php echo $r1['name'];?></td> 
									
									<?php									
									}
																	
									?>
									<td><?php echo $r['total_amount'];?></td> 
									<td><?php echo $r['total_quantity'];?></td> 
									<td><?php echo $r['order_date'];?></td>
									
									<?php
									$id=$r['da_id'];
									$q1="select * from delivery_add where da_id='$id'";
									$c1=mysqli_query($con,$q1);
									while($r1=mysqli_fetch_array($c1))
									{
									?>
										<td>
											<?php echo $r1['app_flat']."<br>".$r1['nearby']."<br>".$r1['locality'].",".$r1['city'].",".$r1['postalcode'];?>
										</td> 
									
									<?php									
									}
									?>
									<td><?php echo $r['status'];?></td>
									<td>
				
										<a title="View Order Items" href="vieworderitem.php?id=<?php echo $r['order_id'];?>" style="color: green;  font-size:18px">View</a>
										<br/>
										<a title="Cancel" href="editorder.php?id=<?php echo $r['order_id'];?>&status=Cancel" style="color: green;  font-size:18px">C</a>
										&nbsp;&nbsp;
										<a title="Approved" href="editorder.php?id=<?php echo $r['order_id'];?>&status=Approved" style="color: green;  font-size:18px">A</a>&nbsp;&nbsp;
										<a title="Shipped" href="editorder.php?id=<?php echo $r['order_id'];?>&status=Shipped" style="color: green;  font-size:18px">S</a>&nbsp;&nbsp;
										<a title="Delivered" href="editorder.php?id=<?php echo $r['order_id'];?>&status=Delivered" style="color: green;  font-size:18px">D</a>
									</td> 
								</tr> 
							 </tbody>
							<?php
							}
							?>
						</table>
						</div>
					</div>
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
				
			</div>
		</div>
	
<?php
include "footer.php";
?>