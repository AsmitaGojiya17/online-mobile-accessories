<?php
session_start();
unset($_SESSION['seller']);

?>

<script>
	window.location="login.php";
</script>	
