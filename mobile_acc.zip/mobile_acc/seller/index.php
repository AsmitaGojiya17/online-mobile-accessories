<?php
include "header.php";
?>


		<div class="charts" >		
			<div class="mid-content-top charts-grids" >
				<div class="middle-content" >
						
					<!-- start content_slider -->
					<div id="owl-demo" class="owl-carousel text-center" >
						<center>
						<h1>Welcome <br><br>To<br><br>Seller-Panel</h1>
							</center>
						
					</div>
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
				
			</div>
		</div>
	
<?php
include "footer.php";
?>


