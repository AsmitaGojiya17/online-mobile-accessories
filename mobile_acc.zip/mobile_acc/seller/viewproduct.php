<?php
include "header.php";
?>


		<div class="charts" >		
			<div class="mid-content-top charts-grids" >
				<div class="middle-content" >
						
					<h1>Product Listing</h1>
					<a href="addproduct.php" style="float: right">Add New product</a>
					<!-- start content_slider -->
					<div class="bs-example widget-shadow" data-example-id="hoverable-table"> 
						<div class="panel-body widget-shadow">
						<table class="table table-hover"> 
							<thead> 
								<tr>  
									<th>Category</th> 
									<th>Product-Name</th> 
									<th>Product-Image</th> 
									<th>Specification</th> 
									<th>Price</th> 
									
									<th>Action</th> 
								</tr> 
							</thead> 
							<?php
								include "connection.php";
							$c=mysqli_query($con,"select * from product_details");
							while($r=mysqli_fetch_array($c))
							{
							?>
							<tbody> 
								<tr> 
									
									<td><?php echo $r['category_name'];?></td> 
									<td><?php echo $r['product_name'];?></td> 
									<td><img src="upload/product/<?php echo $r['product_image'];?>" height=100 width=100/></td> 
									<td><?php echo $r['specification'];?></td> 
									<td><?php echo $r['price'];?></td> 
									
									<td>
									<a href="editproduct.php?id=<?php echo $r['product_id'];?>">
										<i style="color: green; font-size:18px " class="fa fa-pencil-square-o" aria-hidden="true"></i>
									</a>
									&nbsp;
									<a onClick="return confirm('Are You Sure You want to remove this information??')" href="deleteproduct.php?id=<?php echo $r['product_id'];?>">
										<i  style="color: red;  font-size:18px" class="fa fa-trash-o" aria-hidden="true"></i>
									</a>
									</td> 
								</tr> 
							 </tbody>
							<?php
							}
							?>
						</table>
						</div>
					</div>
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
				
			</div>
		</div>
	
<?php
include "footer.php";
?>