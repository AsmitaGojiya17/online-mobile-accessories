<?php
include "header.php";
if(isset($_POST['btnok']))
{
	include "connection.php";
	$cname=$_POST['slcategory'];
	
	$bname=$_POST['nmtxt'];
	$specification=$_POST['pubtxt'];
	$price=$_POST['pricetxt'];
	$cmp=$_POST['cmptxt'];
	$gtxt=$_POST['gtxt'];
	
	$image1=$_FILES['flimg1']['name'];
	$image2=$_FILES['flimg2']['name'];
	$image3=$_FILES['flimg3']['name'];
	$image4=$_FILES['flimg4']['name'];
	$image5=$_FILES['flimg5']['name'];
	$sid=$_SESSION['s_id'];
	$q="insert into product_details values('','$bname','$cname','$image1','$image2','$image3','$image4','$image5','$specification','$price','$cmp','$gtxt','$sid')";
	$c=mysqli_query($con,$q);
	if($c)
	{
		move_uploaded_file($_FILES['flimg1']['tmp_name'],"upload/product/".$image1);
		move_uploaded_file($_FILES['flimg2']['tmp_name'],"upload/product/".$image2);
		move_uploaded_file($_FILES['flimg3']['tmp_name'],"upload/product/".$image3);
		move_uploaded_file($_FILES['flimg4']['tmp_name'],"upload/product/".$image4);
		move_uploaded_file($_FILES['flimg5']['tmp_name'],"upload/product/".$image5);
		
		echo "<script>alert('Successfully Inserted'); window.location='viewproduct.php'; </script>";
	}
	else
	{
		echo "<script>alert('Something Goes Wrong');</script>";
	}
	
}


?>



		<div class="charts" >		
			<div class="mid-content-top charts-grids" >
				<div class="middle-content" >
						
					<div class="form-three widget-shadow">
							<form class="form-horizontal" action="#" method="post" enctype="multipart/form-data">
							<h3>Add New Product</h3><br>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Category-Name</label>
									<div class="col-sm-8">
										<select name="slcategory" class="form-control1">
											<option>Select Category</option>
											<?php
											include "connection.php";
											$q="select * from category";
											$c=mysqli_query($con,$q);
											while($r=mysqli_fetch_array($c))
											{
												?>
												<option value="<?php echo $r['cat_id'];?>"><?php echo $r['category_name'];?></option>
												<?php
											}
											?>
										</select>
									</div>
								</div>
								
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Product-Name</label>
									<div class="col-sm-8">
										<input type="text" name="nmtxt" class="form-control1" id="focusedinput" placeholder="Enter Name">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Product-Image1</label>
									<div class="col-sm-8">
										<input type="file" name="flimg1" class="form-control1">
									</div>
								</div><div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Product-Image2</label>
									<div class="col-sm-8">
										<input type="file" name="flimg2" class="form-control1">
									</div>
								</div><div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Product-Image3</label>
									<div class="col-sm-8">
										<input type="file" name="flimg3" class="form-control1">
									</div>
								</div><div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Product-Image4</label>
									<div class="col-sm-8">
										<input type="file" name="flimg4" class="form-control1">
									</div>
								</div><div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Product-Image5</label>
									<div class="col-sm-8">
										<input type="file" name="flimg5" class="form-control1">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Specification</label>
									<div class="col-sm-8">
										<input type="text" name="pubtxt" class="form-control1" id="focusedinput" placeholder="Specification">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Price</label>
									<div class="col-sm-8">
										<input type="text" name="pricetxt" class="form-control1" id="focusedinput" placeholder="Enter Price">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Company</label>
									<div class="col-sm-8">
										<input type="text" name="cmptxt" class="form-control1" id="focusedinput" placeholder="Enter Price">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Guaranety</label>
									<div class="col-sm-8">
										<input type="text" name="gtxt" class="form-control1" id="focusedinput" placeholder="Enter Price">
									</div>
								</div>
								
							<div class="form-group">
									<div class="col-sm-6" align="center">
									<button type="submit" class="btn btn-default" name="btnok">Submit</button>
									</div>
								</div>
							</form>
						</div>
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
				
			</div>
		</div>
	
<?php
include "footer.php";
?>


