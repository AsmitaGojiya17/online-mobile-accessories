<?php
session_start();
include "header2.php";
include "connection.php";
if(isset($_POST['submit']))
{
	$newpw=$_POST['newpw'];
	$confpw=$_POST['confpw'];
	if($newpw == $confpw)
	{
	$eml=$_SESSION['tempeml'];	
	$qr="update customer set password='$newpw' where email='$eml'";
	$rs=mysqli_query($con,$qr);
	if($rs)
	{
		?><script> 
				alert("Your Password Updated Successfully");
				window.location="login.php"
		</script>
		<?php 
	}
	else
	{
		?> 	<script> alert("Retype Please");
				window.location="updatepw.php"
			</script> 
		<?php
	}
	}
	else
	{
		?> 	
			<script> alert("New Password and Confirm Password are not matching");
				window.location="updatepw.php"
			</script> 
		<?php
	}
}

?>

<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Forget Password</h2>
					    <form action="#" method="post">
							<div>
						     	<span><label>New Password</label></span>
						    	<span><input type="text" name="newpw" placeholder="New Password"></span>
						    </div>
						   <div>
						     	<span><label>Confirm Password</label></span>
						    	<span><input type="text" name="confpw" placeholder="Confirm Password"></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Confirm"  class="myButton" name="submit"></span>
						  </div>
							
					    </form>
				  </div>
  				</div>
				
			  </div>		
         </div> 
    </div>
 </div>
 <?php
include "footer2.php";
?>