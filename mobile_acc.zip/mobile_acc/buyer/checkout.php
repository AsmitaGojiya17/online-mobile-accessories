<head>
<style>
	#abc{
		border:1px solid black; 
		vertical-align: center; 
		padding-left:10px; 
		padding-top:10px;
		padding-bottom:10px;
	}
</style>

</head>

<?php
include "header2.php";
include "connection.php";
if(!isset($_SESSION['user']))
{
	?>
	<script>
		alert('You have to login first');
		window.location="login.php";
	</script>
	<?php
}
if(isset($_POST['submit']))
{
	$af=$_POST['aftxt'];
	$nearby=$_POST['natxt'];
	$pcode=$_POST['pctxt'];
	$city=$_POST['ctxt'];
	$loca=$_POST['ltxt'];
	$userid=$_SESSION['user'];
	$q="insert into delivery_add values('','$userid','$af','$nearby','$loca','$city','$pcode')";
	$ccc=mysqli_query($con,$q);
	?>
	<script>
	alert('Address Added successfully');
	window.location="checkout.php";
	</script>
	<?php
}
if(isset($_POST['btnok']))
{
	if(!isset($_POST['rbtn']))
	{
		?>
		<script>
			alert("Please select any one address");
			window.location="checkout.php";
		</script>
		<?php
	}
	else
	{
		$userid=$_SESSION['user'];
		$q="select * from cart where user_id='$userid'";
		$c=mysqli_query($con,$q);
		$tq=0; $tp=0; $tnet=0;
		while($r=mysqli_fetch_array($c))
		{
				
					$pid=$r['prod_id'];
					$q1="select * from product_details where product_id='$pid'";
					$c1=mysqli_query($con,$q1);
					while($rr=mysqli_fetch_array($c1))
					{
						$pname=$rr['product_name'];
						$price=$rr['price'];
						$image=$rr['product_image'];
					}
					$tq=$tq+$r['quantity'];
					$tp=$tp+$price;
					$tnet=$tnet+($price*$r['quantity']);
				
		}
		$date=date("d-m-Y");
		$da_id=$_POST['rbtn'];
		$query="Insert into order_master values('','$userid','$tnet','$tq','$date','$da_id','Pending')";
		mysqli_query($con,$query);
		$latest_id = $con->insert_id;
		
		$userid=$_SESSION['user'];
		$q="select * from cart where user_id='$userid'";
		$c=mysqli_query($con,$q);
		while($r=mysqli_fetch_array($c))
		{
				$pid=$r['prod_id'];
				$q1="select * from product_details where product_id='$pid'";
				$c1=mysqli_query($con,$q1);
				while($rr=mysqli_fetch_array($c1))
				{
					$pname=$rr['product_name'];
					$price=$rr['price'];
					$image=$rr['product_image'];
				}
				$qnty=$r['quantity'];
				$tprice=$qnty*$price;
				$qry="Insert into order_items_details 
				values('','$latest_id','$pid','$qnty','$price','$tprice')";
				mysqli_query($con,$qry);
		}
		$qq="delete from cart where user_id='$userid'";
		mysqli_query($con,$qq);
		?>
		<script>
			alert('Your order has been Placed successfully');
			window.location="index.php";
		</script>
		<?php
	}
}

?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>My Addresses</h3>
    		</div>
    		
    		<div class="clear"></div>
    	</div>
	      <div class="section group"><br/><br/>
				<?php
					include "connection.php";
					$userid=$_SESSION['user'];
					$q="select * from delivery_add where user_name='$userid'";
					$c=mysqli_query($con,$q);
					$nr=mysqli_num_rows($c);
				if($nr>=1)
				{
				?>
				<div style="float:left;">
					<form action="#" method="post">
					<table style="font-family:orkney; border-collapse:collapse; border:1px solid black; padding:10 10 10 10" width=150%>
					<tr>
						<th style="border:1px solid black; padding-top:10px; padding-bottom:10px">Select</th>
						<th style="border:1px solid black;">Address</th>
						<th style="border:1px solid black;">Action</th>
					</tr>
					<?php
					while($r=mysqli_fetch_array($c))
					{
					?>
						<tr style="border:1px solid black;">
							<td id="abc"><input type="radio" value="<?php echo $r['da_id'];?>" name="rbtn"/></td>
							<td id="abc"><?php echo $r['app_flat']."<br>".$r['nearby']."<br>".$r['locality']."<br>".$r['city']."<br/>".$r['postalcode'];?></td>
							<td id="abc"><a onclick="return confirm('Are you sure you want to remove this item from cart??');" href="deleteaddress.php?cid=<?php echo $r['da_id'];?>">Remove</a></td>
						</tr>
					<?php
					}
					?>
					
				</table>
				<br/><br/>
				
						<input type="submit" name="btnok" value="Place Order" style="border: 1px solid #5C5655; padding: 8px 20px; font-size: 12px; width:125px; margin: 0; font-weight: bold; cursor: pointer; background: #565656; color: #fff; text-shadow: 0 1px 0 rgba(0, 0, 0, 0.2);"/>
						</form>
				</div>
				<?php
				}
				else
				{
					?>
					<h1 style="font-size:25px; text-align:center; font-family:orkney; color:#B81D22">You have not set any address</h1>
				<?php
				}
				?>
			<div class="contact-form" style="width:50%; float:right">
				  	<h2>Add New Address</h2>
					    <form action="#" method="post">
						    <div>
						    	<span><label>Appartment / Flat</label></span>
						    	<span><input type="text" class="textbox" name="aftxt" placeholder="Appartment / Flat"></span>
						    </div>
						    <div>
						     	<span><label>Near Area</label></span>
						    	<span><input type="text" class="textbox" name="natxt" placeholder="Near Area"></span>
						    </div>
							<div>
						     	<span><label>Locality</label></span>
						    	<span><input type="text" class="textbox" name="ltxt" placeholder="Locality"></span>
						    </div>
							<div>
						     	<span><label>Postal Code</label></span>
						    	<span><input type="text" class="textbox" name="pctxt" placeholder="Postal Code"></span>
						    </div>
							<div>
						     	<span><label>City</label></span>
						    	<span><input type="text" class="textbox" name="ctxt" placeholder="City"></span>
						    </div>
						   <div>
								
								<input type="submit" value="Add Address" class="myButton" name="submit" align="center">
								
						   </div>
							
					    </form>
				  </div>
			</div>
			<br><br>
			
    </div>
 </div>
</div>
<?php
include "footer.php"
?>