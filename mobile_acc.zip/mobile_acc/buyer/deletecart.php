<?php

	$cid=$_REQUEST['cid'];
	include "connection.php";
	$q="delete from cart where cart_id='$cid'";
	mysqli_query($con,$q);
	

?>
<script>
	window.location="cart.php";
</script>