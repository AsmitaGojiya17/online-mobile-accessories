<head>
<style>
	#abc{
		border:1px solid black; 
		vertical-align: center; 
		text-align:center; 
		padding-top:10px;
		padding-bottom:10px;
	}
</style>

</head>

<?php
include "header2.php";
if(!isset($_SESSION['user']))
{
	?>
	<script>
		alert('You have to login first');
		window.location="login.php";
	</script>
	<?php
}
if(isset($_POST['btnok']))
{
	?>
	<script>
		window.location="checkout.php";
	</script>
	<?php
}

?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>My Cart</h3>
    		</div>
    		
    		<div class="clear"></div>
    	</div>
	      <div class="section group"><br/><br/>
				<?php
					include "connection.php";
					$userid=$_SESSION['user'];
					$q="select * from cart where user_id='$userid'";
					$c=mysqli_query($con,$q);
					$nr=mysqli_num_rows($c);
				if($nr>=1)
				{
				?>
					<table style="font-family:orkney; border-collapse:collapse; border:1px solid black; padding:10 10 10 10" width=100%>
					<tr>
						<th style="border:1px solid black; padding-top:10px; padding-bottom:10px">Image</th>
						<th style="border:1px solid black;">Name</th>
						<th style="border:1px solid black;">Net Amount</th>
						<th style="border:1px solid black;">Quantity</th>
						<th style="border:1px solid black;">Total Amount</th>
						<th style="border:1px solid black;">Action</th>
					</tr>
				<?php 
					$tq=0;
					$tp=0;
					$tnet=0;
					while($r=mysqli_fetch_array($c))
					{
						$pid=$r['prod_id'];
						$q1="select * from product_details where product_id='$pid'";
						$c1=mysqli_query($con,$q1);
						while($rr=mysqli_fetch_array($c1))
						{
							$pname=$rr['product_name'];
							$price=$rr['price'];
							$image=$rr['product_image'];
						}
						$tq=$tq+$r['quantity'];
						$tp=$tp+$price;
						$tnet=$tnet+($price*$r['quantity']);
						
						
					?>
						<tr style="border:1px solid black;">
							<td id="abc"><img src="../seller/upload/product/<?php echo $image;?>" height=80 width=80 /></td>
							<td id="abc"><?php echo $pname;?></td>
							<td id="abc"><?php echo $price;?></td>
							<td id="abc"><?php echo $r['quantity'];?></td>
							<td id="abc"><?php echo $price*$r['quantity'];?></td>
							<td id="abc"><a onclick="return confirm('Are you sure you want to remove this item from cart??');" href="deletecart.php?cid=<?php echo $r['cart_id'];?>">Remove</a></td>
						</tr>
					<?php
					}
					?>
					<tr>
						<td id="abc"></td>
						<td id="abc"></td>
						<td id="abc"></td>
						<td id="abc">Total Quantity:<?php echo $tq;?></td>
						<td id="abc">Paid Amount:<?php echo $tnet;?></td>
						<td id="abc">	
						<form action="#" method="post">
						<input type="submit" name="btnok" value="Checkout Order" style="border: 1px solid #5C5655; padding: 8px 20px; font-size: 12px; width:125px; margin: 0; font-weight: bold; cursor: pointer; background: #565656; color: #fff; text-shadow: 0 1px 0 rgba(0, 0, 0, 0.2);"/>
						</form>
			</td>
					</tr>
				</table>
				<?php
				}
				else
				{
					?>
					<h1 style="font-size:25px; text-align:center; font-family:orkney; color:#B81D22">Your cart is empty. Please add some product</h1>
				<?php
				}
				?>
			</div>
    </div>
 </div>
</div>
<?php
include "footer.php"
?>