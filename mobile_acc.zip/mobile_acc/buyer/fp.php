<?php

include "header2.php";
include "connection.php";
if(isset($_POST['submit']))
{
	$email=$_POST['email'];
	$que=$_POST['que'];
	$ans=$_POST['ans'];	
	$qr="select * from customer where email='$email' AND question='$que' AND answer='$ans'";
	$rs=mysqli_query($con,$qr);
	$num=mysqli_num_rows($rs);
	if($num>=1)
	{
		$_SESSION['tempeml']=$email;
		?><script> 
				window.location="updatepw.php"
		</script>
		<?php 
	}
	else
	{
		?> 	<script> alert("You are not Registered user");
				window.location="fp.php"
			</script> 
		<?php
	}
}

?><head>
	<style>
	.selclass
		{
			padding: 8px;
			display: block;
			width: 101%;
			background: none;
			border: 1px solid #CACACA;
			outline: none;
			color: #464646;
			font-size: 1em;
			font-weight: bold;
			font-family: Arial, Helvetica, sans-serif;
			-webkit-appearance: none;
		}
	</style>
</head>

<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Forget Password</h2>
					    <form action="#" method="post">
							<div>
						     	<span><label>E-mail</label></span>
						    	<span><input type="text" name="email" placeholder="E-mail"></span>
						    </div>
						   <div>
						     	<span><label>Question</label></span>
								<span><select class="selclass" name="que" placeholder="Question">
									<option value="What is Your Nick Name ??">
										What is Your Nick Name ??
									</option>
									<option value="What is Your First School Name ??">
										What is Your First School Name ??
									</option>
									<option value="What is Your Personal Secret ??">
										What is Your Personal Secret ??
									</option>
									<option value="Which one is Your First bike name ??">
										What is Your First bike name ??
									</option>
										</select></span>
						    </div>
						    <div>
						     	<span><label>Answer</label></span>
						    	<span><input type="text" class="textbox" name="ans" placeholder="Answer"></span>
						    </div>
							<div>
						    	<span><a href="register.php">Register ??</a></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Change Password"  class="myButton" name="submit"></span>
						  </div>
							
					    </form>
				  </div>
  				</div>
				
			  </div>		
         </div> 
    </div>
 </div>
 <?php
include "footer2.php";
?>