<?php
include "header2.php";
include "connection.php";
if(isset($_POST['btnsub']))
{
		$name=$_POST['name'];
		$unm=$_POST['unm'];
		$gen=$_POST['gen'];
		$email=$_POST['email'];
		$contact=$_POST['contact'];
		$city=$_POST['city'];
		$address=$_POST['address'];
		$password=$_POST['password'];
		$que=$_POST['que'];
		$ans=$_POST['ans'];
		$qr="INSERT INTO customer VALUES('','$name','$unm','$gen','$email','$contact','$city','$address','$password','$que','$ans')";
		$res=mysqli_query($con,$qr);
		if($res)
		{
		?> 
			<script> 
				alert("You are Registered Successfully");
				window.location="index.php";
			</script> 
		<?php
		}
}
?>
<head>
	<style>
	.selclass
		{
			padding: 8px;
			display: block;
			width: 101%;
			background: none;
			border: 1px solid #CACACA;
			outline: none;
			color: #464646;
			font-size: 1em;
			font-weight: bold;
			font-family: Arial, Helvetica, sans-serif;
			-webkit-appearance: none;
		}
	</style>
</head>
<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Register</h2>
					    <form action="#" method="post">
					    	<div>
						    	<span><label>Full Name</label></span>
						    	<span><input type="text"  name="name" placeholder="Full Name"></span>
						    </div>
						    <div>
						    	<span><label>Username</label></span>
						    	<span><input type="text" class="textbox" name="unm" placeholder="Username"></span>
						    </div>
						    <div>
						     	<span><label>Gender</label></span>
						    	<span><input type="radio" name="gen" value="Male">Male
					  &nbsp &nbsp &nbsp &nbsp
                    <input type="radio" name="gen" value="female">Female</span>
						    </div>
							<div>
						     	<span><label>E-mail</label></span>
						    	<span><input type="text" name="email" placeholder="E-mail"></span>
						    </div>
							<div>
						     	<span><label>Contact</label></span>
						    	<span><input type="text" class="textbox" name="contact" placeholder="Contact"></span>
						    </div>
							<div>
						     	<span><label>City</label></span>
						    	<span><input type="text" class="textbox" name="city" placeholder="City"></span>
						    </div>
							<div>
						     	<span><label>Address</label></span>
						    	<span><input type="text" class="textbox" name="address" placeholder="Address"></span>
						    </div>
							<div>
						     	<span><label>Password</label></span>
						    	<span><input type="password" class="textbox" name="password" placeholder="Password"></span>
						    </div>
							<div>
						     	<span><label>Question</label></span>
								<span><select class="selclass" name="que" placeholder="Question">
									<option value="What is Your Nick Name ??">
										What is Your Nick Name ??
									</option>
									<option value="What is Your First School Name ??">
										What is Your First School Name ??
									</option>
									<option value="What is Your Personal Secret ??">
										What is Your Personal Secret ??
									</option>
									<option value="Which one is Your First bike name ??">
										What is Your First bike name ??
									</option>
										</select></span>
						    </div>
							<div>
						     	<span><label>Answer</label></span>
						    	<span><input type="text" class="textbox" name="ans" placeholder="Answer"></span>
						    </div>
							
						   <div>
						   		<span><input type="submit" value="Submit"  class="myButton" name="btnsub"></span>
						  </div>
						
					    </form>
						   		
						  
				  </div>
  				</div>
				
			  </div>		
         </div> 
    </div>
 </div>
 <?php
include "footer2.php";
?>