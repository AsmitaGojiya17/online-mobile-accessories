<?php
include "header2.php";
if(isset($_POST['submit']))
{
	include "connection.php";
		$unm=$_POST['unm'];
		$message=$_POST['message'];
		$subject=$_POST['subject'];
		$email=$_POST['email'];
		$f_date=date("d-m-Y");
		$qr="insert into feedback values('','$unm','$message','$subject','$email','$f_date')";
		$res=mysqli_query($con,$qr);
		if($res)
		{
			?>	<script>alert("Your Feedback is submitted successfully");
				window.location="feedback.php";
				</script>  <?php
		}
}
?>
<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Feedback</h2>
					    <form action="#" method="post">
					    	<div>
						    	<span><label>Username</label></span>
						    	<span><input type="text" class="textbox" name="unm" placeholder="Username"></span>
						    </div>
						    <div>
						    	<span><label>E-mail</label></span>
						    	<span><input type="text" class="textbox" name="email" placeholder="E-mail"></span>
						    </div>
						    <div>
						     	<span><label>Subject</label></span>
						    	<span><input type="text" class="textbox" name="subject" placeholder="Subject"></span>
						    </div>
						    <div>
						    	<span><label>Message</label></span>
						    	<span><textarea name="message" placeholder="Message"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit"  class="myButton" name="submit"></span>
						  </div>
					    </form>
				  </div>
  				</div>
				
			  </div>		
         </div> 
    </div>
 </div>
 <?php
include "footer2.php";
?>