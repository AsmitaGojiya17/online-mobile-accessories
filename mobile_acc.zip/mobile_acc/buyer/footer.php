  
  <div class="footer">
   	  <div class="wrap">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>Why buy from us</h4>
						<p style="font-family:orkney; letter-height:5px; padding-left:10px">
						We are providing all types of Mobile Accessories. You can purchase any type of Mobile accessories like memory card, back cover, headphone etc. from our website.
						</p>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Information</h4>
						<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="category.php">Product</a></li>
						<li><a href="register.php">Register</a></li>
						<li><a href="cart.php">My Cart</a></li>
						<li><a href="myorder.php">My Order</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>My account</h4>
						<ul>
							<li><a href="cart.php">My Cart</a></li>
							<li><a href="myorder.php">My Order</a></li>
							<li><a href="login.php">Login</a></li>
							<li><a href="fp.php">Forget Password</a></li>
							<li><a href="feedback.php">Help</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+91-9012345678</span></li>
							<li><span>+91 9898121212</span></li>
						</ul>
						
				</div>
			</div>			
        </div>
        <div class="copy_right">
				<p>&copy; 2022 Copyright@ Mobile Accessories shop. All rights reserved | Design by Gojiya Asmita,Kasundra Srushti,Keshwala Vandana</p>
		   </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"><span id="toTopHover"> </span></a>
</body>
</html>

