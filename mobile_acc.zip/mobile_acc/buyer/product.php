<?php
include "header2.php"
?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Products</h3>
    		</div>
    		
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
				
				<?php 
					include "connection.php";
					$cid=$_REQUEST['cid'];
					$cname=$_REQUEST['cname'];
					$q="select * from product_details where category_name='$cid'";
					$c=mysqli_query($con,$q);
					while($r=mysqli_fetch_array($c))
					{
						
				?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="productdetails.php?pid=<?php echo $r['product_id'];?>&cname=<?php echo $cname;?>"><img src="../seller/upload/product/<?php echo $r['product_image'];?>" style="height:200px; width:250px" alt="" />					<hr>
					 <h2><?php echo $r['product_name'];?> </h2></a>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">Rs. <?php echo $r['price'];?></span></p>
					    </div>
					       		<div class="add-cart">								
									<h4><a href="productdetails.php?pid=<?php echo $r['product_id'];?>&cname=<?php echo $cname;?>">View Details</a></h4>
							     </div>
							 <div class="clear"></div>
					</div>
				</div>
				<?php
					}
					?>
				
			</div>
    </div>
 </div>
</div>
<?php
include "footer.php"
?>