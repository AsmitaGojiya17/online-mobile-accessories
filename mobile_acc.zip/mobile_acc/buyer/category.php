<?php
include "header2.php"
?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Category</h3>
    		</div>
    		
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
				
				<?php 
					include "connection.php";
					$q="select * from category";
					$c=mysqli_query($con,$q);
					while($r=mysqli_fetch_array($c))
					{
						
				?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="product.php?cid=<?php echo $r['cat_id'];?>&cname=<?php echo $r['category_name'];?>"><img src="../admin/upload/category/<?php echo $r['category_image'];?>" style="height:200px; width:250px" alt="" />					<hr>
					 <h2><?php echo $r['category_name'];?> </h2></a>
					
				</div>
				<?php
					}
					?>
				
			</div>
    </div>
 </div>
</div>
<?php
include "footer.php"
?>