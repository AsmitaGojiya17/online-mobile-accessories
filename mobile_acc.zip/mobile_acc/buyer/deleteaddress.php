<?php

	$cid=$_REQUEST['cid'];
	include "connection.php";
	$q="delete from delivery_add where da_id='$cid'";
	mysqli_query($con,$q);
	

?>
<script>
	window.location="checkout.php";
</script>