<?php 
session_start();
?>
<!DOCTYPE HTML>
<head>
<title>Welcome to Mobile Acc. Shop</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
</head>
<body>
  <div class="wrap">
	<div class="header">
		<div class="headertop_desc">
			
			<div class="account_desc">
				<ul>
					<?php
					if(!isset($_SESSION['user']))
					{
						?>
					<li><a href="register.php">Register</a></li>
					<li><a href="login.php">Login</a></li>
						
						<?php
					}
					else
					{
						?>
					<li><a href="logout.php">Logout</a></li>
						
						<?php
					}
					?>
					
					<li><a href="myorder.php">My Account</a></li>
				</ul>
			</div>
			<div class="clear"></div>
		</div>
		<div class="header_top">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" height=100 alt="" /></a>
			</div>
			  <?php if(isset($_SESSION['user']))
			  {
				 ?>
			  <div class="cart">
			  	   <?php
				   include "connection.php";
				   $userid=$_SESSION['user'];
				   $qq="select * from cart where user_id='$userid'";
				   $cc=mysqli_query($con,$qq);
				   $rr=mysqli_num_rows($cc);
				   ?>
				   <p>
				   <a href="cart.php"><span>Cart:</span>
				   <?php echo $rr;?>&nbsp; items
			  	   	</b></p></a>
			  </div>
			  <?php
			  }
			  ?>
			  <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#dd') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown-2').removeClass('active');
				});

			});

		</script>
	 <div class="clear"></div>
  </div>
	<div class="header_bottom">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="category.php">Products</a></li>
			    	
			    	<li><a href="myorder.php">My Account</a></li>
			    	<li><a href="feedback.php">Feedback</a></li>
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="search_box">
	     		<form>
				
	     			<?php
					if(isset($_SESSION['user']))
					{
						echo "Welcome ".$_SESSION['username'];
					}
					?>
	     		</form>
	     	</div>
	     	<div class="clear"></div>
	     </div>	     	
   </div>