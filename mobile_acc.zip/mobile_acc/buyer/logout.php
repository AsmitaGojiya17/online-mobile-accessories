<?php
session_start();
unset($_SESSION['unm']);
unset($_SESSION['user']);

?>

<script>
	window.location="index.php";
</script>	
