<?php
include "header2.php";
include "connection.php";
if(isset($_POST['submit']))
{
	$email=$_POST['email'];
	$password=$_POST['password'];	
	$qr="select * from customer where email='$email' AND password='$password'";
	$rs=mysqli_query($con,$qr);
	$num=mysqli_num_rows($rs);
	if($num>=1)
	{
		while($r=mysqli_fetch_array($rs))
		{
			$_SESSION['unm']=$email;
			$_SESSION['username']=$r['name'];
			$_SESSION['user']=$r['customer_id'];
		}
		if(isset($_REQUEST['pid']))
		{
			?>
			<script> 
				window.location="productdetails.php?pid=<?php echo $_REQUEST['pid'];?>&cname=<?php echo $_REQUEST['cname'];?>"
			</script>
			<?php
		}
		else
		{
			?>
			<script> 
				alert("You are Logged in Successfully");
				window.location="index.php"
			</script>
			<?php
		}		
	}
	else
	{
		?> 	<script> alert("Enter Valid Username or Password");
				window.location="login.php"
			</script> 
		<?php
	}
}

?>
<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Login</h2>
					    <form action="#" method="post">
						    <div>
						    	<span><label>E-mail</label></span>
						    	<span><input type="text" class="textbox" name="email" placeholder="E-mail"></span>
						    </div>
						    <div>
						     	<span><label>Password</label></span>
						    	<span><input type="password" class="textbox" name="password" placeholder="Password"></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit"  class="myButton" name="submit"></span>
						  </div>
							<div>
							<span><a href="fp.php">Forget Password</a></span>
							</div>
					    </form>
				  </div>
  				</div>
				
			  </div>		
         </div> 
    </div>
 </div>
 <?php
include "footer2.php";
?>