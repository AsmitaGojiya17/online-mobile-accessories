<?php
include "header.php"
?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>New Products</h3>
    		</div>
    		
    		<div class="clear"></div>	
    	</div>
	      <div class="section group">
		  <?php 
			include "connection.php";
			$q="SELECT * FROM product_details ORDER BY product_id DESC LIMIT 4";
			$c=mysqli_query($con,$q);
			while($r=mysqli_fetch_array($c))
			{
				?>
				
			<div class="grid_1_of_4 images_1_of_4">
					 <img src="../seller/upload/product/<?php echo $r['product_image'];?>" style="height:200px; width:250px"  alt="" />
					 <hr>
					 <h2><?php echo $r['product_name'];?></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">Rs.<?php echo $r['price'];?></span></p>
					    </div>
					       		
							 <div class="clear"></div>
					</div>
					 
			</div>
			<?php
			}
			?>
				
			</div>
			
			
    </div>
 </div>
</div>
<?php
include "footer.php"
?>