<head>
<style>
	#abc{
		border:1px solid black; 
		vertical-align: center; 
		text-align:center; 
		padding-top:10px;
		padding-bottom:10px;
	}
</style>

</head>

<?php
if(isset($_POST['btnok']))
{
	?>
	<script>
		window.location="checkout.php";
	</script>
	<?php
}
include "header2.php";
if(!isset($_SESSION['user']))
{
	?>
	<script>
		alert('You have to login first');
		window.location="login.php";
	</script>
	<?php
}
?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>My Cart</h3>
    		</div>
    		
    		<div class="clear"></div>
    	</div>
	      <div class="section group"><br/><br/>
				<?php
					include "connection.php";
					$userid=$_SESSION['user'];
					$q="select * from services_master where username='$userid'";
					$c=mysqli_query($con,$q);
					$nr=mysqli_num_rows($c);
				if($nr>=1)
				{
				?>
					<table style="font-family:orkney; border-collapse:collapse; border:1px solid black; padding:10 10 10 10" width=100%>
					<tr>
						<th style="border:1px solid black; padding-top:10px; padding-bottom:10px">Image</th>
						<th style="border:1px solid black;">Product</th>
						<th style="border:1px solid black;">OrderId</th>
						<th style="border:1px solid black;">Title</th>
						<th style="border:1px solid black;">Message</th>
						<th style="border:1px solid black;">Date</th>
						
					</tr>
				<?php 
					while($r=mysqli_fetch_array($c))
					{
						$pid=$r['pro_id'];
						$q1="select * from product_details where product_id='$pid'";
						$c1=mysqli_query($con,$q1);
						while($rr=mysqli_fetch_array($c1))
						{
							$pname=$rr['product_name'];
							
						}
						
						
					?>
						<tr style="border:1px solid black;">
							<td id="abc"><img src="../admin/upload/service/<?php echo $r['image'];?>" height=80 width=80 /></td>
							<td id="abc"><?php echo $pname;?></td>
							<td id="abc"><?php echo $r['order_id'];?></td>
							<td id="abc"><?php echo $r['title'];?></td>
							<td id="abc"><?php echo $r['message'];?></td>
							<td id="abc"><?php echo $r['s_date'];?></td>
							
						</tr>
						<table width=100% style="font-family:orkney;">
						<tr style="border:1px solid black;">
							<td id="abc" style="text-align:left; padding-left:20px; color:#B81D22" colspan=2>Service Status Details</td>
						</tr>
						
						<tr style="border:1px solid black;">
							<td id="abc" width=75%>Status</td>
							<td id="abc">Date</td>
						</tr>
						<?php
						$s_id=$r['service_id'];
						$q2="select * from status_master where service_id='$s_id'";
						$c2=mysqli_query($con,$q2);
						$cr=mysqli_num_rows($c2);
						if($cr>=1)
						{
							while($r2=mysqli_fetch_array($c2))
							{
								?>
							<tr style="border:1px solid black;">
								<td id="abc" width=75%><?php echo $r2['message'];?></td>
								<td id="abc"><?php echo $r2['date'];?></td>
							</tr>	
								<?php
							}
						}
						else{
						?>
							<tr style="border:1px solid black;">
								<td id="abc" colspan=2>No any action had been taken</td>
							</tr>	
						<?php						
						}
						?>
						</table>
						
					<?php
					}
					?>
					
				</table>
				<?php
				}
				else
				{
					?>
					<h1 style="font-size:25px; text-align:center; font-family:orkney; color:#B81D22">You didnot placed any service</h1>
				<?php
				}
				?>
			</div>
    </div>
 </div>
</div>
<?php
include "footer.php"
?>