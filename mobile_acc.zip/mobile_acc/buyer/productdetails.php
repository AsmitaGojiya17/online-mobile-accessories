<?php 
include "header2.php";
include "connection.php";
$pid=$_REQUEST['pid'];
$cname=$_REQUEST['cname'];
if(isset($_POST['btnok']))
{
	if(!isset($_SESSION['user']))
	{
		?>
		<script>
			alert('You have to login first');
			window.location="login.php?pid=<?php echo $pid;?>&cname=<?php echo $cname;?>";
		</script>
		<?php
	}
	$userid=$_SESSION['user'];
	$qq="select * from cart where user_id='$userid' AND prod_id='$pid'";
	$cc=mysqli_query($con,$qq);
	$rr=mysqli_num_rows($cc);
	if($rr>=1)
	{
			?>
			<script>
			alert('Item Already added');
			window.location="productdetails.php?pid=<?php echo $pid;?>&cname=<?php echo $cname;?>";
			</script>
			<?php
		
	}
	else
	{
		$quantity=$_POST['slqnty'];
		$date=date('d-m-Y');
		$q1="insert into cart values('','$userid','$pid','$quantity','$date')";
		$c1=mysqli_query($con,$q1);
		if($c1)
		{
			?>
			<script>
			alert('Item add successfully into cart');
			window.location="productdetails.php?pid=<?php echo $pid;?>&cname=<?php echo $cname;?>";
			</script>
			<?php
		}
		else
		{
			?>
			<script>
			alert('Something goes wrong');
			</script>
			<?php
		}
	}
}
?>
<head>
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<link href="css/easy-responsive-tabs.css" rel="stylesheet" type="text/css" media="all"/>
<link rel="stylesheet" href="css/global.css">
<script src="js/slides.min.jquery.js"></script>
<script>
		$(function(){
			$('#products').slides({
				preload: true,
				preloadImage: 'img/loading.gif',
				effect: 'slide, fade',
				crossfade: true,
				slideSpeed: 350,
				fadeSpeed: 500,
				generateNextPrev: true,
				generatePagination: false
			});
		});
	</script>
</head>

 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="back-links">
			<?php
				$cname=$_REQUEST['cname'];
				$pid=$_REQUEST['pid'];
				$q="select * from product_details where product_id='$pid'";
				$c=mysqli_query($con,$q);
				while($r=mysqli_fetch_array($c))
				{
					$pname=$r['product_name'];
					$price=$r['price'];
					$description=$r['specification'];
					
					$image1=$r['product_image'];
					$image2=$r['image2'];
					$image3=$r['image3'];
					$image4=$r['image4'];
					$image5=$r['image5'];
				}
			?>
    		<b>Home >>>> <a href="#"><?php echo $cname;?></a></b>
    	    </div>
    		<div class="clear"></div>
    	</div>
    	<div class="section group">
				<div class="cont-desc span_1_of_2">
				  <div class="product-details">				
					<div class="grid images_3_of_2">
						<div id="container">
						   <div id="products_example">
							   <div id="products">
								<div class="slides_container">
									<a href="#" target="_blank"><img src="../seller/upload/product/<?php echo $image1;?>" alt=" "  /></a>
									<a href="#" target="_blank"><img src="../seller/upload/product/<?php echo $image2;?>" alt=" "  /></a>
									<a href="#" target="_blank"><img src="../seller/upload/product/<?php echo $image3;?>" alt=" "  /></a>					
									<a href="#" target="_blank"><img src="../seller/upload/product/<?php echo $image4;?>" alt=" "  /></a>
									<a href="#" target="_blank"><img src="../seller/upload/product/<?php echo $image5;?>" alt=" "  /></a>
									<a href="#" target="_blank"><img src="../seller/upload/product/<?php echo $image1;?>" alt=" " /></a>
								</div>
								<ul class="pagination">
									<li><a href="#"><img src="../seller/upload/product/<?php echo $image1;?>" alt=" " style="height:41px; width:55px" /></a></li>
									<li><a href="#"><img src="../seller/upload/product/<?php echo $image2;?>" alt=" "  style="height:41px; width:55px"/></a></li>
									<li><a href="#"><img src="../seller/upload/product/<?php echo $image3;?>" alt=" " style="height:41px; width:55px"/></a></li>
									<li><a href="#"><img src="../seller/upload/product/<?php echo $image4;?>" alt=" " style="height:41px; width:55px" /></a></li>
									<li><a href="#"><img src="../seller/upload/product/<?php echo $image5;?>" alt=" " style="height:41px; width:55px"/></a></li>
									<li><a href="#"><img src="../seller/upload/product/<?php echo $image1;?>" alt=" "  style="height:41px; width:55px"/></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="desc span_3_of_2">
					<h2><?php echo $pname;?> </h2>
					<p><?php echo $description;?></p>					
					<div class="price">
						<p>Price: <span>Rs.<?php echo $price;?></span></p>
					</div>
					
					<div class="available">
						<p>Available Options :</p>
					<form action="#" method="post">
					<ul>
						<li>Quality:<select name="slqnty">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select></li>
						<input style="border: 1px solid #5C5655; padding: 8px 20px;font-size: 12px; width:125px; margin: 0; font-weight: bold; cursor: pointer; background: #565656; color: #fff; text-shadow: 0 1px 0 rgba(0, 0, 0, 0.2);" type="submit" value="Add to Cart" name="btnok"/>
					
					</ul>
					</form>
					</div>
				 
			</div>
			<div class="clear"></div>
		  </div>
		
	    <script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true   // 100% fit in a container
        });
    });
   </script>		
        </div>
				
 		</div>
 	</div>
    </div>
 </div>
   
<?php
include "footer.php";
?>