<?php
include "header2.php";
include "connection.php";
$oid=$_REQUEST['oid'];
$pid=$_REQUEST['pid'];

if(isset($_POST['submit']))
{
	$satxt=$_POST['satxt'];
	$msgtxt=$_POST['msgtxt'];	
	$sbtxt=$_POST['sbtxt'];	
	$userid=$_SESSION['user'];
	$img=$_FILES['pimage']['name'];
	$date=date("d-m-Y");
	$qr="insert into services_master values('','$userid','$oid','$pid','$sbtxt','$msgtxt','$img','$satxt','$date')";
	$rs=mysqli_query($con,$qr);
	if($rs)
	{
			move_uploaded_file($_FILES['pimage']['tmp_name'],"../admin/upload/service/".$img);
			?>
			<script> 
				alert("Your Service request had been placed successfully");
				window.location="index.php";
			</script>
			<?php
	}
	else
	{
			?>
			<script> 
				alert("Something goes wrong");
			</script>
			<?php
	}		
	
}

?>
<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Fill Service Details</h2>
					    <form action="#" method="post" enctype="multipart/form-data">
						    
						    <div>
						     	<span><label>Subject</label></span>
						    	<span><input type="text" class="textbox" name="sbtxt" placeholder="Subject"></span>
						    </div>
							<div>
						     	<span><label>Select Product Image</label></span>
						    	<span><input type="file" class="textbox" name="pimage"></span>
						    </div>
						    <div>
						     	<span><label>Message</label></span>
						    	<span><textarea type="text" class="textbox" name="msgtxt" placeholder="Message"></textarea></span>
						    </div> 
							<div>
						     	<span><label>Service Address</label></span>
						    	<span><textarea type="text" class="textbox" name="satxt" placeholder="Address"></textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit"  class="myButton" name="submit"></span>
						  </div>
							<div>
							
							</div>
					    </form>
				  </div>
  				</div>
				
			  </div>		
         </div> 
    </div>
 </div>
 <?php
include "footer2.php";
?>