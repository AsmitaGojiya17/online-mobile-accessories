<head>
<style>
	#abc{
		border:1px solid black; 
		vertical-align: center; 
		text-align:center; 
		padding-top:10px;
		padding-bottom:10px;
	}
</style>

</head>

<?php
if(isset($_POST['btnok']))
{
	?>
	<script>
		window.location="checkout.php";
	</script>
	<?php
}
include "header2.php";
if(!isset($_SESSION['user']))
{
	?>
	<script>
		alert('You have to login first');
		window.location="login.php";
	</script>
	<?php
}
?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>My Order</h3>
    		</div>
    		
    		<div class="clear"></div>
    	</div>
	      <div class="section group"><br/><br/>
				<?php
					include "connection.php";
					$userid=$_SESSION['user'];
					$q="select * from order_master where username='$userid'";
					$c=mysqli_query($con,$q);
					$nr=mysqli_num_rows($c);
				if($nr>=1)
				{
					while($r=mysqli_fetch_array($c))
					{
				?>
					<table style="font-family:orkney; border-collapse:collapse; border:1px solid black; " width=100%>
					<tr>
						<td style="padding:10px 10px 10px 10px; color:#B81D22">OrderId : <?php echo $r['order_id'];?><br/><br/>Date : <?php echo $r['order_date'];?></td>
						<td style="padding:10px 30px 10px 10px; text-align:right">Total Quantity : <?php echo $r['total_quantity'];?><br/><br>Total Amount : <?php echo $r['total_amount'];?></td>
					</tr>
					<tr>
					<?php 
						$da_id=$r['da_id'];
						$qq="select * from delivery_add where da_id='$da_id'";
						$cc=mysqli_query($con,$qq);
						while($rr=mysqli_fetch_array($cc))
						{
						?>
							<td style="padding:10px 10px 10px 10px">Address : <?php echo $rr['app_flat'].", ".$rr['nearby'].", ".$rr['locality'].", ".$rr['city'].",".$rr['postalcode'];?></td>
							<td style="color:#B81D22; padding:10px 30px 10px 10px; text-align:right">Status : <?php echo $r['status'];?></td>
							
						<?php
						}
						?>
					</tr>
				<?php 
					
						$oid=$r['order_id'];
						$q1="select * from order_items_details where order_id='$oid'";
						$c1=mysqli_query($con,$q1);
					?>
					<table style="font-family:orkney; border-collapse:collapse; border:1px solid black; padding:10 10 10 10" width=100%>
					<tr>
						<th style="border:1px solid black; padding-top:10px; padding-bottom:10px">Image</th>
						<th style="border:1px solid black;">Name</th>
						<th style="border:1px solid black;">Net Amount</th>
						<th style="border:1px solid black;">Quantity</th>
						<th style="border:1px solid black;">Total Amount</th>
					
					</tr>
					
						<?php
						while($r1=mysqli_fetch_array($c1))
						{
							$pid=$r1['book_id'];
							$q2="select * from product_details where product_id='$pid'";
							$c2=mysqli_query($con,$q2);
							while($r2=mysqli_fetch_array($c2))
							{
								$image=$r2['product_image'];
								$pname=$r2['product_name'];
							}
						?>
						<tr style="border:1px solid black;">
							<td id="abc"><img src="../seller/upload/product/<?php echo $image;?>" height=80 width=80 /></td>
							<td id="abc"><?php echo $pname;?></td>
							<td id="abc"><?php echo $r1['price'];?></td>
							<td id="abc"><?php echo $r1['quantity'];?></td>
							<?php $price=$r1['price']; ?>
							<td id="abc"><?php echo $price*$r1['quantity'];?></td>
									</tr>
					<?php
						}
						?>
						</table>
						<?php
					}
					?>
					
				</table>
				<?php
				}
				else
				{
					?>
					<h1 style="font-size:25px; text-align:center; font-family:orkney; color:#B81D22">You have no any order</h1>
				<?php
				}
				?>
			</div>
    </div>
 </div>
</div>
<?php
include "footer.php"
?>